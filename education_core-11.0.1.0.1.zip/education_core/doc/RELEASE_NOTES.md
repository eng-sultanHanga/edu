## Module education_core

#### 12.06.2018
#### Version 11.0.1.0.0
##### ADD
- Initial commit for Educational ERP Project

#### 12.06.2018
#### Version 11.0.1.0.1
##### ADD
- [ADD] Application Report
- [UPDT] Kanban views for Class
- [ADD] Admission Analysis